
#include <iostream>
#include "yaml-cpp/yaml.h"

using namespace std;

int main(int argc, char **argv)
{
    YAML::Node config;
    // 当文件不存在或yaml格式出错时，抛异常
    try
    {
        config = YAML::LoadFile("/home/uthuqinghong/Desktop/334455/999/yaml_cpp_test/src/config.yaml");
    }
    catch (...)
    {
        printf("error loading file, yaml file error or not exist.\n");
        return 0;
    }

    // 获取类型
    for (YAML::const_iterator it = config.begin(); it != config.end(); ++it)
    {
        std::string key = it->first.as<std::string>();
        YAML::Node value = it->second;
        switch (value.Type())
        {
        case YAML::NodeType::Scalar:
            printf("key: %s scalar\n", key.c_str());
            break;
        case YAML::NodeType::Sequence:
            printf("key: %s Sequence\n", key.c_str());
            cout << "seq: " << value << endl;
            break;
        case YAML::NodeType::Map:
            printf("key: %s Map\n", key.c_str());
            break;
        case YAML::NodeType::Null:
            printf("key: %s Null\n", key.c_str());
            break;
        case YAML::NodeType::Undefined:
            printf("key: %s Undefined\n", key.c_str());
            break;
            // etc.
        }
    }

    // 顶层
    cout << "version:" << config["version"].as<float>() << endl;
    cout << "version(str):" << config["version"].as<string>() << endl;
    cout << "need:" << config["need"].as<bool>() << endl; // 输出值为1
    cout << "time:" << config["time"].as<string>() << endl;
    cout << "empty:" << config["empty"].as<string>() << endl;

    try
    {
        printf("sizeof array: %d\n", (int)config["fruit"].size());
        // cout << "fruit1:\n" << config["fruit"] << endl; //此处返回Node
        // 索引方式取
        // for (int i = 0; i < (int)config["fruit"].size(); i++)
        // {
        //     cout << "fruit2: " << config["fruit"][i].as<string>() << endl;
        // }
        // 单个取
        for (auto item : config["fruit"])
        {
            cout << "fruit3: " << item.as<string>() << endl;
        }
    }
    catch (...)
    {
        printf("fruit not ok.\n");
    }

    try
    {
        printf("new sta: \n");
        for (auto item : config["multi"]["sta"])
        {
            printf("%s \n", item.as<string>().c_str());
        }
        printf("\n");
    }
    catch (...)
    {
        // printf("key not exist...\n");
        // return 0;
    }

    // 对于不存在的key，似乎只能用try
    try
    {
        cout << "bad:" << config["bad"].as<int>() << endl;
    }
    catch (...)
    {
        printf("key bad not exist...\n");
        // return 0;
    }

    cout << "text:" << config["text"].as<string>() << endl;
    // 有两层
    printf("name: %s \nname1: %s \nage: %d\n",
           config["my"]["name"].as<string>().c_str(),
           config["my"]["name1"].as<string>().c_str(),
           config["my"]["age"].as<int>());

    return 0;
}
