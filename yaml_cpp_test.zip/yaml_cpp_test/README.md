# 说明

这是一个使用yaml-cpp解析YAML文件的demo.使用到了yaml-cpp编译出来的静态库，[yaml-cpp-0.7.0](https://github.com/jbeder/yaml-cpp/tree/yaml-cpp-0.7.0).

当前使用静态库，动态库的配置可以参考[yaml-cpp动态库CMake](https://github.com/supercollider/supercollider/blob/main/cmake_modules/FindYamlCpp.cmake).

# 使用方式

mkdir build

cd build

cd build

cmake ..

make -j2

# 运行

```
uos@uos-pc:~/Desktop/yaml_cpp_test/build$ ./src/yaml_test 
key: name scalar
key: version scalar
key: need scalar
key: time scalar
key: empty scalar
key: my Map
key: text scalar
key: fruit Sequence
seq: - apple
- apple1
- apple2
- apple3
- apple4
- apple5
key: multi Map
version:2
version(str):2.0
need:1
time:2020-10-03T09:21:13
empty:nul
sizeof array: 6
fruit3: apple
fruit3: apple1
fruit3: apple2
fruit3: apple3
fruit3: apple4
fruit3: apple5
new sta: 
110 210 ddd 99 
133 135 1 2 1588 1509 
310-410 
333-444 

bad:key bad not exist...
text:hello
world!

name: late \n lee 
name1: late 
 lee 
age: 99

```

# 参考文档

* [yaml文件解析：c++篇](https://blog.csdn.net/subfate/article/details/111994720?ydreferer=aHR0cHM6Ly93d3cuZ29vZ2xlLmNvbS5oay8%3D)
* https://github.com/Liuyvjin/notebook/tree/master/Cmake
* https://github.com/jbeder/yaml-cpp/tree/yaml-cpp-0.7.0
* [https://stackoverflow.com/questions/36403287/compiler-error-with-yaml-cpp-undefined-reference-to-yamldetailnode-data](https://stackoverflow.com/questions/36403287/compiler-error-with-yaml-cpp-undefined-reference-to-yamldetailnode-data)
* https://github.com/supercollider/supercollider/blob/main/cmake_modules/FindYamlCpp.cmake
